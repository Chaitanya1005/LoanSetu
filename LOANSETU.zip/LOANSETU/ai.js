const Groq = require("groq-sdk");

const client = new Groq({
  apiKey: process.env.GROQ_API_KEY,
});

const SYSTEM_PROMPT = `
You are LoanSetu, a friendly loan assistant.

RULES:
1. You ONLY talk about business loans.
2. Keep replies VERY short (2 lines max).
3. ALWAYS:
   - Acknowledge the user's last answer,
   - Then ask the next question naturally.
4. NEVER extract data. That is handled separately.
5. NEVER loop or repeat unless the user is unclear.
6. Tone should be like a helpful bank representative.
`;

async function askAI(history) {
  try {
    const completion = await client.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      temperature: 0.3,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        ...history
      ]
    });

    return completion.choices[0].message.content.trim();

  } catch (err) {
    console.error("AI ERROR:", err);
    return "Sorry, I’m facing a technical issue.";
  }
}

module.exports = { askAI };
