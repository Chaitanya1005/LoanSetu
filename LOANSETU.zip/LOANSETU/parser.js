// parser.js — Extract structured loan data from user messages

function normalizeText(text) {
    return text.toLowerCase().replace(/\s+/g, " ").trim();
}

//----------------------------------------
// BUSINESS TYPE CLASSIFIER
//----------------------------------------
function detectBusinessType(text) {
    const t = normalizeText(text);

    if (t.match(/textile|kapda|garment|boutique|readymade|silai|stitch|apparel/))
        return "textile";

    if (t.match(/wholesale|wholesaler|stockist|trading|trader/))
        return "trading";

    if (t.match(/retail|shop|dukan|store|kirana/))
        return "retail";

    if (t.match(/factory|manufacturing|unit|karkhana|plant/))
        return "manufacturing";

    if (t.match(/ca|chartered accountant|audit|tax|practitioner|accountant/))
        return "chartered accountant";

    if (t.match(/food|bakery|namkeen|oil mill|rice mill|atta chakki|papad|masala/))
        return "food processing";

    if (t.match(/vendor|rehdi|redi|larry|hawker|thela|stall/))
        return "street vendor";

    if (t.match(/services|consult|agency/))
        return "services";

    // Vague answers
    if (t.match(/business|self business|my own business/))
        return null; // ask clarification

    return null;
}

//----------------------------------------
// YES / NO DETECTION
//----------------------------------------
function detectYes(text) {
    return !!text.match(/yes|haan|ha|hanji|bilkul|yep|sure/);
}

function detectNo(text) {
    return !!text.match(/no|nahi|na|nope/);
}

//----------------------------------------
// LOAN AMOUNT DETECTION
//----------------------------------------
function detectLoanAmount(text) {
    let t = normalizeText(text);

    let match = t.match(/([\d\.]+)\s*(lakh|lac|lakhs)/);
    if (match) return parseFloat(match[1]) * 100000;

    match = t.match(/([\d\.]+)\s*(crore|cr)/);
    if (match) return parseFloat(match[1]) * 10000000;

    match = t.match(/([\d,]+)/);
    if (match) return parseInt(match[1].replace(/,/g, ""));

    return null;
}

//----------------------------------------
// VINTAGE DETECTION
//----------------------------------------
function detectVintage(text) {
    let t = normalizeText(text);

    let match = t.match(/(\d+)\s*year/);
    if (match) return parseInt(match[1]);

    match = t.match(/since\s*(\d{4})/);
    if (match) return new Date().getFullYear() - parseInt(match[1]);

    return null;
}

//----------------------------------------
// COLLATERAL STORED
//----------------------------------------
function detectCollateral(text) {
    if (detectYes(text)) return "yes";
    if (detectNo(text)) return "no";
    return null;
}

//----------------------------------------
// GST / Udyam detection
//----------------------------------------
function detectGST(text) {
    if (detectYes(text)) return "yes";
    if (detectNo(text)) return "no";
    return null;
}

function detectUdyam(text) {
    if (detectYes(text)) return "yes";
    if (detectNo(text)) return "no";
    return null;
}

//----------------------------------------
// EXPORT PARSER
//----------------------------------------
module.exports = {
    detectBusinessType,
    detectLoanAmount,
    detectVintage,
    detectCollateral,
    detectGST,
    detectUdyam,
    detectYes,
    detectNo
};
