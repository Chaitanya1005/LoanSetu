const { askAI } = require("./ai");
const parser = require("./parser");
const { recommendBestScheme } = require("./rule_engine");

function createEmptySession() {
  return {
    language: null,
    stage: "choose_language",
    history: [],
    data: {
      business_type: null,
      gst_registered: null,
      udyam_registered: null,
      vintage_years: null,
      loan_amount: null,
      loan_purpose: null,
      collateral_available: null
    }
  };
}

const GREET = {
  en: `Hello! I am LoanSetu, your personal loan assistant.

I will ask a few simple questions to suggest the best loan scheme.
I NEVER ask for Aadhaar, PAN, bank details or OTP.

What type of business do you have?`,
  hi: `नमस्ते! मैं LoanSetu हूँ, आपका लोन असिस्टेंट।

मैं आपको कुछ सरल सवाल पूछकर सही लोन योजना बताऊँगा।
मैं कभी भी आधार, पैन, बैंक विवरण या OTP नहीं पूछता।

आपका व्यवसाय किस प्रकार का है?`
};

function allFilled(d) {
  return Object.values(d).every(v => v !== null);
}

function buildSummary(d, lang) {
  return `
Here is what I understood:

• Business Type: ${d.business_type}
• GST: ${d.gst_registered}
• Udyam: ${d.udyam_registered}
• Vintage: ${d.vintage_years} years
• Loan Amount: ₹${d.loan_amount}
• Purpose: ${d.loan_purpose}
• Collateral: ${d.collateral_available}

Please confirm if this is correct (yes/no).
`;
}

async function handleUserMessage(text, session) {

  // -------- LANGUAGE SELECTION ---------
  if (session.stage === "choose_language") {
    if (text.includes("1")) session.language = "en";
    else if (text.includes("2")) session.language = "hi";
    else return { reply: "Choose: 1) English 2) हिंदी" };

    session.stage = "collecting";
    return { reply: GREET[session.language] };
  }

  // ADD TO HISTORY
  session.history.push({ role: "user", content: text });

  // -------- PARSING THE USER TEXT ---------
  const d = session.data;

  const bt = parser.detectBusinessType(text);
  if (bt && !d.business_type) d.business_type = bt;

  const gst = parser.detectGST(text);
  if (gst && d.gst_registered === null) d.gst_registered = gst;

  const udyam = parser.detectUdyam(text);
  if (udyam && d.udyam_registered === null) d.udyam_registered = udyam;

  const vint = parser.detectVintage(text);
  if (vint && !d.vintage_years) d.vintage_years = vint;

  const amt = parser.detectLoanAmount(text);
  if (amt && !d.loan_amount) d.loan_amount = amt;

  const coll = parser.detectCollateral(text);
  if (coll && !d.collateral_available) d.collateral_available = coll;

  if (!d.loan_purpose && text.length > 3 && d.loan_amount)
    d.loan_purpose = text; // take as purpose

  // -------- CHECK IF ALL DATA FILLED ---------
  if (allFilled(d) && session.stage !== "summary") {
    session.stage = "summary";
    return { reply: buildSummary(d, session.language) };
  }

  // -------- SUMMARY CONFIRMATION ---------
  if (session.stage === "summary") {
    if (parser.detectYes(text)) {
      const best = recommendBestScheme(d);
      return {
        reply: `The best matching loan scheme is:\n⭐ ${best.scheme_name} ⭐\n${best.special_notes}`
      };
    }
    if (parser.detectNo(text)) {
      session.stage = "collecting";
      return { reply: "Okay, tell me what needs to be corrected." };
    }
  }

  // -------- ASK AI FOR NEXT QUESTION ---------
  const aiReply = await askAI(session.history);
  session.history.push({ role: "assistant", content: aiReply });

  return { reply: aiReply };
}

module.exports = { handleUserMessage, createEmptySession };
