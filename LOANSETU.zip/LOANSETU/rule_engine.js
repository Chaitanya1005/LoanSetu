const schemes = require("./schemes.json");

function scoreScheme(scheme, user) {
  let score = 0;

  if (scheme.customer_type.includes(user.business_type)) score += 3;

  if (scheme.needs_gst === "Yes" && user.gst_registered === "Yes") score += 2;
  if (scheme.needs_gst === "Optional") score += 1;

  if (scheme.needs_udyam === "Yes" && user.udyam_registered === "Yes") score += 2;
  if (scheme.needs_udyam === "Optional") score += 1;

  if (user.vintage_years >= scheme.min_vintage_years) score += 1;

  if (user.loan_amount >= scheme.min_amount && user.loan_amount <= scheme.max_amount)
    score += 3;

  if (scheme.primary_purpose.includes(user.loan_purpose)) score += 2;

  if (scheme.needs_collateral === "Yes" && user.collateral_available !== "None") score += 2;

  return score;
}

function recommendBestScheme(user) {
  let best = null;
  let bestScore = -1;

  for (const scheme of schemes) {
    const score = scoreScheme(scheme, user);
    if (score > bestScore) {
      best = scheme;
      bestScore = score;
    }
  }

  return best;
}

module.exports = { recommendBestScheme };
